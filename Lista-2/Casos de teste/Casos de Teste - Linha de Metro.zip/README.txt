Arquivo zip gerado em: 21/07/2023 22:38:30 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [2 - Condicional] Linha de Metrô